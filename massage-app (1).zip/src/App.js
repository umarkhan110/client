import "./css/style.css"
import "./css/login.css"
import "./css/custom-menu.css"
import "./css/session-book.css"
import Main from "./pages/Main";
function App() {
  return (
    <Main />
  );
}

export default App;
